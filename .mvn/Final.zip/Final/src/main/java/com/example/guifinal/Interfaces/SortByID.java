package com.example.guifinal.Interfaces;

public interface SortByID {
    void sortByID();
}