package com.example.guifinal.Interfaces;

public interface SortByNameOrTitle {
    void sortByNameOrTitle();
}
